"""
Quick sanity check: run the full pipeline on the bundled sample
documents and print a summary. Also usable as a CLI smoke test:
    python tests/test_pipeline.py
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.extraction.document_reader import load_documents_from_folder
from backend.pipeline import process_documents

SAMPLE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "sample_documents")


def main():
    raw_docs = load_documents_from_folder(SAMPLE_DIR)
    assert len(raw_docs) == 7, f"expected 7 sample docs, found {len(raw_docs)}"

    result, graph = process_documents(raw_docs, patient_name="Demo Patient")

    print("=== SUMMARY ===")
    print(json.dumps(result["summary"], indent=2))

    print("\n=== DOCUMENTS ===")
    for d in result["documents"]:
        print(f"  {d['filename']:35s} type={d['doc_type']:18s} date={d['doc_date']}")

    print("\n=== TIMELINE ===")
    for day in result["timeline"]["timeline"]:
        print(f"  {day['date']}")
        for ev in day["events"]:
            print(f"     [{ev['type']:10s}] {ev['name']} "
                  f"{ev['value'] or ''}{ev['unit'] or ''}  (src: {ev['source_filename']})")

    print("\n=== MEDICATION JOURNEYS ===")
    for j in result["medication_journeys"]:
        print(f"  {j['drug_name']} -> current status: {j['current_status']}")
        for step in j["steps"]:
            print(f"      {step['date']} {step['status']:15s} "
                  f"dosage={step['dosage']} src={step['source_filename']}")

    print("\n=== LAB TRENDS ===")
    for t in result["lab_trends"]:
        print(f"  {t['test_name']} ({t['direction_as_documented']})")
        for p in t["series"]:
            print(f"      {p['date']}  {p['value']}{p['unit'] or ''}  src={p['source_filename']}")

    print("\n=== CONFLICTS ===")
    if not result["conflicts"]:
        print("  none detected")
    for c in result["conflicts"]:
        print(f"  [{c['conflict_type']}] {c['message']}")

    print("\n=== GRAPH ===")
    print(f"  nodes={len(result['graph']['nodes'])} edges={len(result['graph']['edges'])}")

    # Basic assertions to catch regressions
    assert result["summary"]["entity_count"] > 0
    assert any(t["test_name"].lower() == "hemoglobin" for t in result["lab_trends"])
    assert any(j["drug_name"].lower() == "iron" for j in result["medication_journeys"])
    assert len(result["conflicts"]) >= 1, "expected at least one detected conflict in demo data"

    print("\nAll smoke assertions passed.")


if __name__ == "__main__":
    main()
