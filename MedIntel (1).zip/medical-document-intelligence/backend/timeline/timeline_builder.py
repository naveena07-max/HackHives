"""
Builds the chronological Patient-Event Timeline from extracted entities.
Grouped by date so the UI can render a day-by-day view, and each event
keeps full source traceability.
"""
from collections import defaultdict


def build_timeline(entities):
    by_date = defaultdict(list)
    undated = []
    for e in entities:
        d = e.to_dict()
        if e.date:
            by_date[d["date"]].append(d)
        else:
            undated.append(d)

    timeline = []
    for date in sorted(by_date.keys()):
        events = sorted(by_date[date], key=lambda x: x["type"])
        timeline.append({"date": date, "events": events})

    return {"timeline": timeline, "undated_events": undated}
