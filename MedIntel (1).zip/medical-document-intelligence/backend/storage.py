"""
Very small in-memory store keyed by session_id.
Swap this for a real DB (Mongo/Postgres) for production use - the rest
of the pipeline only depends on this simple dict-like interface.
"""
import uuid

_SESSIONS = {}


def new_session():
    sid = str(uuid.uuid4())[:12]
    _SESSIONS[sid] = {}
    return sid


def save(session_id, key, value):
    _SESSIONS.setdefault(session_id, {})[key] = value


def get(session_id, key, default=None):
    return _SESSIONS.get(session_id, {}).get(key, default)


def exists(session_id):
    return session_id in _SESSIONS
