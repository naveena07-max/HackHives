"""
End-to-end pipeline:
  raw documents -> entity extraction -> graph -> timeline -> analyses

Kept as a single orchestrator function so the API layer stays thin and
the pipeline can also be run from a CLI/test script without Flask.
"""
from .extraction.entity_extractor import extract_entities_from_document
from .graph.graph_builder import build_graph, graph_to_json
from .timeline.timeline_builder import build_timeline
from .analysis.medication_journey import build_medication_journeys
from .analysis.lab_trends import build_lab_trends
from .analysis.conflict_detector import detect_conflicts


def process_documents(raw_docs, patient_name="Patient"):
    all_entities = []
    documents_meta = []

    for raw_doc in raw_docs:
        doc_type, doc_date, entities = extract_entities_from_document(raw_doc)
        documents_meta.append({
            "doc_id": raw_doc.doc_id,
            "filename": raw_doc.filename,
            "doc_type": doc_type,
            "doc_date": doc_date.strftime("%Y-%m-%d") if doc_date else None,
            "entity_count": len(entities),
        })
        all_entities.extend(entities)

    graph = build_graph(all_entities, patient_name=patient_name)
    graph_json = graph_to_json(graph)
    timeline = build_timeline(all_entities)
    medication_journeys = build_medication_journeys(all_entities)
    lab_trends = build_lab_trends(all_entities)
    conflicts = detect_conflicts(all_entities)

    return {
        "documents": documents_meta,
        "entities": [e.to_dict() for e in all_entities],
        "graph": graph_json,
        "timeline": timeline,
        "medication_journeys": medication_journeys,
        "lab_trends": lab_trends,
        "conflicts": conflicts,
        "summary": {
            "document_count": len(documents_meta),
            "entity_count": len(all_entities),
            "conflict_count": len(conflicts),
            "medication_count": len(medication_journeys),
            "lab_test_count": len(lab_trends),
        },
    }, graph
