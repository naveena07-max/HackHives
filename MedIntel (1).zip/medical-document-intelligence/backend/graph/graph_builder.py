"""
Builds the Cross-Document Relationship Graph.

Nodes  = Patient + every extracted Entity (Symptom, LabTest, LabResult,
         Diagnosis, Medication, Procedure, FollowUp)
Edges  = typed relationships between them, e.g.
         Patient --experienced--> Symptom
         Symptom --investigated_via--> LabTest
         LabTest --yields--> LabResult
         LabResult --supports--> Diagnosis
         Diagnosis --treated_with--> Medication
         Medication --leads_to--> FollowUp
         LabResult --followed_by--> LabResult   (same test, later date -> trend)
         Medication --continued/dosage_changed/stopped--> Medication (journey)

The graph is intentionally built with clear, inspectable heuristics
(temporal proximity + document co-occurrence) rather than a black-box
model, so every edge can be explained and traced back to evidence.
"""
import networkx as nx

TYPE_ORDER = ["Symptom", "LabTest", "LabResult", "Diagnosis", "Medication",
              "Procedure", "FollowUp"]

EDGE_LABELS = {
    ("Patient", "Symptom"): "experienced",
    ("Patient", "LabTest"): "underwent",
    ("Patient", "Procedure"): "underwent",
    ("Symptom", "LabTest"): "investigated_via",
    ("Symptom", "Procedure"): "investigated_via",
    ("LabTest", "LabResult"): "yields",
    ("LabResult", "Diagnosis"): "supports",
    ("Symptom", "Diagnosis"): "supports",
    ("Procedure", "Diagnosis"): "supports",
    ("Diagnosis", "Medication"): "treated_with",
    ("Diagnosis", "Procedure"): "managed_with",
    ("Medication", "FollowUp"): "leads_to",
    ("Procedure", "FollowUp"): "leads_to",
}

MAX_LINK_DAYS = 21  # heuristic window to link events across documents


def _days_between(a, b):
    if a is None or b is None:
        return None
    return abs((a - b).days)


def build_graph(entities, patient_name="Patient"):
    """entities: list of Entity objects (with .date already resolved)."""
    g = nx.DiGraph()
    g.add_node("PATIENT", type="Patient", name=patient_name, date=None,
               source_filename=None, evidence=None, confidence=1.0)

    # sort entities chronologically (undated last) for deterministic linking
    def sort_key(e):
        return (e.date is None, e.date or "")
    ordered = sorted(entities, key=lambda e: (e.date is None, e.date))

    for e in ordered:
        g.add_node(e.id, **e.to_dict())
        edge_label = EDGE_LABELS.get(("Patient", e.type))
        if edge_label:
            g.add_edge("PATIENT", e.id, relation=edge_label)

    # --- 1) Within-document sequential chain, following clinical logic order
    by_doc = {}
    for e in ordered:
        by_doc.setdefault(e.source_doc_id, []).append(e)

    for doc_id, doc_entities in by_doc.items():
        doc_entities_sorted = sorted(doc_entities, key=lambda e: TYPE_ORDER.index(e.type)
                                      if e.type in TYPE_ORDER else 99)
        for i in range(len(doc_entities_sorted)):
            for j in range(i + 1, len(doc_entities_sorted)):
                a, b = doc_entities_sorted[i], doc_entities_sorted[j]
                label = EDGE_LABELS.get((a.type, b.type))
                if label:
                    g.add_edge(a.id, b.id, relation=label, cross_document=False)
                    break  # link to the *next* stage only, avoid over-connecting

    # --- 2) Cross-document temporal linking (e.g. LabResult in one doc ->
    #        Diagnosis in a later document within MAX_LINK_DAYS)
    by_type = {}
    for e in ordered:
        by_type.setdefault(e.type, []).append(e)

    link_pairs = [("Symptom", "LabTest"), ("Symptom", "Diagnosis"),
                  ("LabResult", "Diagnosis"), ("Diagnosis", "Medication"),
                  ("Medication", "FollowUp"), ("LabResult", "FollowUp"),
                  ("Procedure", "Diagnosis")]
    for src_type, dst_type in link_pairs:
        for a in by_type.get(src_type, []):
            for b in by_type.get(dst_type, []):
                if a.source_doc_id == b.source_doc_id:
                    continue  # already linked in step 1
                if g.has_edge(a.id, b.id):
                    continue
                if a.date is None or b.date is None or b.date < a.date:
                    continue
                days = _days_between(a.date, b.date)
                if days is not None and days <= MAX_LINK_DAYS:
                    label = EDGE_LABELS.get((src_type, dst_type), "related_to")
                    g.add_edge(a.id, b.id, relation=label, cross_document=True)

    # --- 3) Lab trend chains: same test name, later date -> followed_by
    lab_results = by_type.get("LabResult", [])
    by_test_name = {}
    for e in lab_results:
        by_test_name.setdefault(e.name.lower(), []).append(e)
    for name, results in by_test_name.items():
        results_sorted = sorted(results, key=lambda e: e.date or "")
        for i in range(len(results_sorted) - 1):
            g.add_edge(results_sorted[i].id, results_sorted[i + 1].id,
                       relation="followed_by", cross_document=True)

    # --- 4) Medication journey chains: same drug name, chronological
    meds = by_type.get("Medication", [])
    by_drug_name = {}
    for e in meds:
        by_drug_name.setdefault(e.name.lower(), []).append(e)
    for name, mentions in by_drug_name.items():
        mentions_sorted = sorted(mentions, key=lambda e: e.date or "")
        for i in range(len(mentions_sorted) - 1):
            status = mentions_sorted[i + 1].extra.get("status_hint", "continued")
            g.add_edge(mentions_sorted[i].id, mentions_sorted[i + 1].id,
                       relation=status, cross_document=True)

    return g


def graph_to_json(g):
    nodes = []
    for node_id, data in g.nodes(data=True):
        d = dict(data)
        d["node_id"] = node_id
        nodes.append(d)
    edges = []
    for u, v, data in g.edges(data=True):
        edges.append({"source": u, "target": v,
                       "relation": data.get("relation", "related_to"),
                       "cross_document": data.get("cross_document", False)})
    return {"nodes": nodes, "edges": edges}


def subgraph_for_date(g, date_str):
    """Return the node/edge ids relevant to a given date, plus their
    directly connected neighbours, for the 'click a timeline date ->
    highlight the graph' interaction."""
    matching = [n for n, d in g.nodes(data=True) if d.get("date") == date_str]
    keep = set(matching)
    for n in matching:
        keep.update(g.predecessors(n))
        keep.update(g.successors(n))
    sub = g.subgraph(keep)
    return graph_to_json(sub)
