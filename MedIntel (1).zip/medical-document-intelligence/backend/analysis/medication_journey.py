"""
Tracks each medication's history across all documents:
started / continued / dosage_changed / stopped / mentioned_elsewhere.
Every step points back to its source document + evidence snippet.
"""
from collections import defaultdict


def build_medication_journeys(entities):
    meds = [e for e in entities if e.type == "Medication"]
    by_name = defaultdict(list)
    for m in meds:
        by_name[m.name.lower()].append(m)

    journeys = []
    for name, mentions in by_name.items():
        mentions_sorted = sorted(mentions, key=lambda e: e.date or "")
        steps = []
        prev_dosage = None
        for i, m in enumerate(mentions_sorted):
            if i == 0:
                status = "started"
            else:
                status = m.extra.get("status_hint", "continued")
                # infer dosage_changed if not explicitly stated but value differs
                if status == "started" and prev_dosage and m.value and m.value != prev_dosage:
                    status = "dosage_changed"
                elif status == "started":
                    status = "mentioned_again"
            prev_dosage = m.value or prev_dosage
            steps.append({
                "status": status,
                "date": m.to_dict()["date"],
                "dosage": m.value,
                "frequency": m.unit,
                "source_filename": m.source_filename,
                "evidence": m.snippet,
                "node_id": m.id,
            })
        journeys.append({
            "drug_name": mentions_sorted[0].name,
            "steps": steps,
            "current_status": steps[-1]["status"] if steps else None,
        })

    journeys.sort(key=lambda j: j["drug_name"].lower())
    return journeys
