"""
Groups repeated lab test results (same test name, same patient) across
documents into a trend series.

Important: per the problem statement, this module displays values
EXACTLY as documented. It does not make a medical judgement about
whether a trend is "good" or "bad" - it only reports direction
(increasing / decreasing / stable) as a factual numeric observation.
"""
from collections import defaultdict


def build_lab_trends(entities):
    results = [e for e in entities if e.type == "LabResult" and e.value is not None]
    by_name = defaultdict(list)
    for r in results:
        by_name[r.name.lower()].append(r)

    trends = []
    for name, points in by_name.items():
        points_sorted = sorted(points, key=lambda e: e.date or "")
        series = []
        for p in points_sorted:
            try:
                numeric_value = float(p.value)
            except (TypeError, ValueError):
                numeric_value = None
            series.append({
                "date": p.to_dict()["date"],
                "value": p.value,
                "numeric_value": numeric_value,
                "unit": p.unit,
                "source_filename": p.source_filename,
                "evidence": p.snippet,
                "node_id": p.id,
            })
        direction = "stable"
        numeric_series = [s["numeric_value"] for s in series if s["numeric_value"] is not None]
        if len(numeric_series) >= 2:
            if numeric_series[-1] > numeric_series[0]:
                direction = "increasing"
            elif numeric_series[-1] < numeric_series[0]:
                direction = "decreasing"
        trends.append({
            "test_name": points_sorted[0].name,
            "unit": points_sorted[0].unit,
            "series": series,
            "direction_as_documented": direction,
            "note": "Values shown exactly as documented in source files. "
                    "Direction is a factual numeric observation, not a "
                    "clinical interpretation.",
        })

    trends.sort(key=lambda t: t["test_name"].lower())
    return trends
