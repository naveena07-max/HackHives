"""
Rule-based conflict detector.

Flags cases where different source documents disagree about a patient's
*current* medication - either a different drug name, or a different
dosage for the same drug - within a short time window, with no explicit
"switched to / dosage changed" note bridging the two mentions.

This module is deliberately conservative and explainable: it never
makes a clinical judgement call (which one is "correct"); it only
surfaces the disagreement, with full source evidence, for a human to
review.
"""
from itertools import combinations

CONFLICT_WINDOW_DAYS = 30


def _days_between(a, b):
    if a is None or b is None:
        return None
    return abs((a - b).days)


def _bridged_by_change_note(m1, m2):
    """True if either mention's context explicitly acknowledges a switch/
    change, meaning this is NOT an unnoticed conflict."""
    for m in (m1, m2):
        if m.extra.get("status_hint") in ("dosage_changed",):
            return True
    return False


def detect_medication_conflicts(entities):
    meds = [e for e in entities if e.type == "Medication"]
    conflicts = []

    # --- Different drug name, overlapping "active" window --------------
    active_meds = [m for m in meds if m.extra.get("status_hint") != "stopped"]
    for m1, m2 in combinations(active_meds, 2):
        if m1.source_doc_id == m2.source_doc_id:
            continue
        if m1.name.lower() == m2.name.lower():
            continue
        days = _days_between(m1.date, m2.date)
        if days is None or days > CONFLICT_WINDOW_DAYS:
            continue
        if _bridged_by_change_note(m1, m2):
            continue
        conflicts.append({
            "conflict_type": "different_medication",
            "message": (f"'{m1.name}' and '{m2.name}' both appear as active "
                        f"medication within {days} day(s) of each other, "
                        f"in different documents, with no note explaining "
                        f"a switch."),
            "records": [
                {"name": m1.name, "dosage": m1.value, "date": m1.to_dict()["date"],
                 "source_filename": m1.source_filename, "evidence": m1.snippet,
                 "node_id": m1.id},
                {"name": m2.name, "dosage": m2.value, "date": m2.to_dict()["date"],
                 "source_filename": m2.source_filename, "evidence": m2.snippet,
                 "node_id": m2.id},
            ],
        })

    # --- Same drug, different dosage, no explicit change note ----------
    by_name = {}
    for m in meds:
        by_name.setdefault(m.name.lower(), []).append(m)
    for name, mentions in by_name.items():
        for m1, m2 in combinations(mentions, 2):
            if m1.source_doc_id == m2.source_doc_id:
                continue
            if not m1.value or not m2.value or m1.value == m2.value:
                continue
            days = _days_between(m1.date, m2.date)
            if days is None or days > CONFLICT_WINDOW_DAYS:
                continue
            if _bridged_by_change_note(m1, m2):
                continue
            conflicts.append({
                "conflict_type": "dosage_mismatch",
                "message": (f"'{m1.name}' dosage recorded as '{m1.value}' in "
                            f"one document and '{m2.value}' in another within "
                            f"{days} day(s), with no explicit dosage-change note."),
                "records": [
                    {"name": m1.name, "dosage": m1.value, "date": m1.to_dict()["date"],
                     "source_filename": m1.source_filename, "evidence": m1.snippet,
                     "node_id": m1.id},
                    {"name": m2.name, "dosage": m2.value, "date": m2.to_dict()["date"],
                     "source_filename": m2.source_filename, "evidence": m2.snippet,
                     "node_id": m2.id},
                ],
            })

    return conflicts


def detect_diagnosis_conflicts(entities):
    """Lightweight secondary check: mutually-exclusive-sounding diagnosis
    keywords appearing close together across different documents.
    Kept intentionally simple / transparent."""
    diagnoses = [e for e in entities if e.type == "Diagnosis"]
    conflicts = []
    for d1, d2 in combinations(diagnoses, 2):
        if d1.source_doc_id == d2.source_doc_id or d1.name.lower() == d2.name.lower():
            continue
        days = _days_between(d1.date, d2.date)
        if days is None or days > CONFLICT_WINDOW_DAYS:
            continue
        # Only flag if one document's snippet contains a negation cue for
        # the other's diagnosis-like wording (very conservative to avoid
        # noisy false positives).
        neg_cues = ["ruled out", "not consistent with", "no evidence of"]
        text_pair = (d1.snippet + " " + d2.snippet).lower()
        if any(cue in text_pair for cue in neg_cues):
            conflicts.append({
                "conflict_type": "diagnosis_disagreement",
                "message": (f"Possible disagreement between '{d1.name}' and "
                            f"'{d2.name}' across documents - review evidence."),
                "records": [
                    {"name": d1.name, "date": d1.to_dict()["date"],
                     "source_filename": d1.source_filename, "evidence": d1.snippet,
                     "node_id": d1.id},
                    {"name": d2.name, "date": d2.to_dict()["date"],
                     "source_filename": d2.source_filename, "evidence": d2.snippet,
                     "node_id": d2.id},
                ],
            })
    return conflicts


def detect_conflicts(entities):
    return detect_medication_conflicts(entities) + detect_diagnosis_conflicts(entities)
