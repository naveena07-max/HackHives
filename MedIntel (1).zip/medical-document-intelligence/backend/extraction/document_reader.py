"""
Reads uploaded / sample files (txt or pdf) into a simple in-memory
Document representation. Keeping this isolated makes it easy to add
more formats (e.g. docx) later without touching extraction logic.
"""
import os
import uuid


class RawDocument:
    def __init__(self, doc_id, filename, text):
        self.doc_id = doc_id
        self.filename = filename
        self.text = text

    def to_dict(self):
        return {"doc_id": self.doc_id, "filename": self.filename}


def read_text_file(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def read_pdf_file(path):
    try:
        import pdfplumber
    except ImportError:
        raise RuntimeError("pdfplumber is required to read PDF files. "
                            "Install with: pip install pdfplumber")
    text_parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_parts.append(page_text)
    return "\n".join(text_parts)


def load_document(path, filename=None):
    """Load a single file from disk into a RawDocument."""
    filename = filename or os.path.basename(path)
    ext = os.path.splitext(filename)[1].lower()
    if ext == ".pdf":
        text = read_pdf_file(path)
    else:
        text = read_text_file(path)
    return RawDocument(doc_id=str(uuid.uuid4())[:8], filename=filename, text=text)


def load_documents_from_folder(folder_path):
    docs = []
    for fname in sorted(os.listdir(folder_path)):
        full_path = os.path.join(folder_path, fname)
        if os.path.isfile(full_path) and fname.lower().endswith((".txt", ".pdf")):
            docs.append(load_document(full_path, fname))
    return docs
