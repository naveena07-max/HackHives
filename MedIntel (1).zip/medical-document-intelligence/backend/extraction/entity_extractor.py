"""
Rule-based Information Extraction module.

Design goals (per problem statement):
 - Works across different document types (lab report, prescription,
   discharge summary, imaging report, clinical note).
 - Produces STRUCTURED entities (typed, dated, valued).
 - Every entity carries traceability back to its source document,
   the exact matched snippet and its character offset.

No external model download is required -> deterministic, fast, and
reliable to run anywhere (important for a hackathon demo / offline eval).
"""
import re
import uuid
from datetime import datetime

from . import vocab
from .date_utils import find_dates, nearest_date_before, doc_primary_date


def _snippet(text, start, end, radius=60):
    s = max(0, start - radius)
    e = min(len(text), end + radius)
    return ("..." if s > 0 else "") + text[s:e].strip() + ("..." if e < len(text) else "")


def _new_id(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def detect_doc_type(text):
    lower = text.lower()
    scores = {}
    for doc_type, keywords in vocab.DOCUMENT_TYPE_KEYWORDS.items():
        scores[doc_type] = sum(lower.count(kw) for kw in keywords)
    best_type = max(scores, key=scores.get)
    if scores[best_type] == 0:
        return "Clinical Note"  # sensible default
    return best_type


class Entity:
    def __init__(self, etype, name, date, source_doc_id, source_filename,
                 snippet, char_start, value=None, unit=None, extra=None,
                 confidence=0.8):
        self.id = _new_id(etype[:3].lower())
        self.type = etype  # Symptom, LabTest, LabResult, Diagnosis, Medication, Procedure, FollowUp
        self.name = name
        self.value = value
        self.unit = unit
        self.date = date  # datetime or None
        self.source_doc_id = source_doc_id
        self.source_filename = source_filename
        self.snippet = snippet
        self.char_start = char_start
        self.extra = extra or {}
        self.confidence = confidence

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "date": self.date.strftime("%Y-%m-%d") if self.date else None,
            "source_doc_id": self.source_doc_id,
            "source_filename": self.source_filename,
            "evidence": self.snippet,
            "confidence": self.confidence,
            "extra": self.extra,
        }


def _extract_keyword_hits(text, keywords, etype, doc_id, filename, dates, doc_date,
                           trigger_words=None, confidence=0.75):
    """Generic keyword-scan extractor used for symptoms / procedures / lab tests
    mentioned without a value, and diagnoses (optionally requiring a trigger
    phrase nearby to reduce false positives)."""
    entities = []
    lower = text.lower()
    seen_spans = set()
    for kw in keywords:
        for m in re.finditer(r"\b" + re.escape(kw) + r"\b", lower):
            start, end = m.start(), m.end()
            if trigger_words:
                window = lower[max(0, start - 40):start]
                if not any(t in window for t in trigger_words):
                    continue
            # avoid duplicate near-identical spans for the same keyword
            key = (kw, start // 20)
            if key in seen_spans:
                continue
            seen_spans.add(key)
            ent_date = nearest_date_before(dates, start, fallback=doc_date)
            entities.append(Entity(
                etype=etype,
                name=kw.title(),
                date=ent_date,
                source_doc_id=doc_id,
                source_filename=filename,
                snippet=_snippet(text, start, end),
                char_start=start,
                confidence=confidence,
            ))
    return entities


LAB_RESULT_PATTERN = re.compile(
    r"([A-Za-z][A-Za-z /\-]{2,40}?)\s*[:\-]\s*"
    r"(\d+(?:\.\d+)?)\s*"
    r"(g/dl|mg/dl|%|mmol/l|meq/l|iu/l|u/l|cells/cumm|/cumm|ng/ml|pg/ml|miu/l|"
    r"mm/hr|million/cumm|k/ul)?",
    re.IGNORECASE,
)

# Drug names must start with a capital letter (as they normally do in real
# prescriptions/notes) - this avoids false positives like "...the Iron
# tablet in this visit" being parsed as a drug called "In This Visit".
MEDICATION_PATTERN = re.compile(
    r"\b(?i:tab|tablet|cap|capsule|inj|injection|syrup|syp|drops)\.?\s+"
    r"([A-Z][A-Za-z\-]*(?:\s[A-Z][A-Za-z\-]*){0,2})"
    r"(?:\s+(\d+(?:\.\d+)?\s?(?:mg|mcg|g|ml|iu))\b)?"
    r"(?:\s*[-,]?\s*((?:once|twice|thrice|1|2|3)\s*(?:a day|daily|/day|times a day)))?"
)

FOLLOWUP_PATTERN = re.compile(
    r"(follow[- ]up|review|revisit|reassess|come back)[^.\n]{0,60}?"
    r"(after\s+\d+\s*(?:day|days|week|weeks|month|months)|on\s+[A-Za-z0-9 ,]{4,20})",
    re.IGNORECASE,
)


def extract_lab_results(text, doc_id, filename, dates, doc_date):
    entities = []
    for m in LAB_RESULT_PATTERN.finditer(text):
        raw_name = m.group(1).strip().lower()
        # Only keep it if the tail of the left-hand side is a known lab
        # test name, and use THAT (not the full raw match) as the entity
        # name - this trims away accidental leading words such as
        # "...showed Hemoglobin" -> "Hemoglobin".
        matched_test = None
        for kw in sorted(vocab.LAB_TESTS, key=len, reverse=True):
            if raw_name == kw or raw_name.endswith(" " + kw):
                matched_test = kw
                break
        if not matched_test:
            continue
        value = m.group(2)
        unit = m.group(3)
        start = m.start()
        ent_date = nearest_date_before(dates, start, fallback=doc_date)
        entities.append(Entity(
            etype="LabResult",
            name=matched_test.title(),
            value=value,
            unit=unit,
            date=ent_date,
            source_doc_id=doc_id,
            source_filename=filename,
            snippet=_snippet(text, start, m.end()),
            char_start=start,
            confidence=0.9,
        ))
    return entities


def extract_medications(text, doc_id, filename, dates, doc_date):
    entities = []
    for m in MEDICATION_PATTERN.finditer(text):
        drug_name = m.group(1).strip()
        dosage = m.group(2)
        frequency = m.group(3)
        start = m.start()
        ent_date = nearest_date_before(dates, start, fallback=doc_date)
        status = "started"
        window = text.lower()[max(0, start - 60):start]
        if any(t in window for t in vocab.STOP_TRIGGERS):
            status = "stopped"
        elif any(t in window for t in vocab.CHANGE_TRIGGERS):
            status = "dosage_changed"
        elif any(t in window for t in vocab.CONTINUE_TRIGGERS):
            status = "continued"
        entities.append(Entity(
            etype="Medication",
            name=drug_name.title(),
            value=dosage,
            unit=frequency,
            date=ent_date,
            source_doc_id=doc_id,
            source_filename=filename,
            snippet=_snippet(text, start, m.end()),
            char_start=start,
            extra={"status_hint": status},
            confidence=0.85,
        ))
    return entities


def extract_followups(text, doc_id, filename, dates, doc_date):
    entities = []
    for m in FOLLOWUP_PATTERN.finditer(text):
        start = m.start()
        ent_date = nearest_date_before(dates, start, fallback=doc_date)
        entities.append(Entity(
            etype="FollowUp",
            name=m.group(0).strip().title(),
            date=ent_date,
            source_doc_id=doc_id,
            source_filename=filename,
            snippet=_snippet(text, start, m.end()),
            char_start=start,
            confidence=0.7,
        ))
    return entities


def extract_diagnoses(text, doc_id, filename, dates, doc_date):
    return _extract_keyword_hits(
        text, vocab.DIAGNOSES, "Diagnosis", doc_id, filename, dates, doc_date,
        trigger_words=None, confidence=0.8,
    )


def extract_symptoms(text, doc_id, filename, dates, doc_date):
    return _extract_keyword_hits(
        text, vocab.SYMPTOMS, "Symptom", doc_id, filename, dates, doc_date,
        confidence=0.75,
    )


def extract_lab_tests_mentioned(text, doc_id, filename, dates, doc_date, already_covered_spans):
    """Catches lab tests *ordered/mentioned* without an inline value
    (e.g. 'Advised: CBC, LFT')."""
    ents = _extract_keyword_hits(
        text, vocab.LAB_TESTS, "LabTest", doc_id, filename, dates, doc_date,
        confidence=0.7,
    )
    # drop ones that overlap a span already captured as a LabResult
    filtered = []
    for e in ents:
        if not any(abs(e.char_start - s) < 15 for s in already_covered_spans):
            filtered.append(e)
    return filtered


def extract_procedures(text, doc_id, filename, dates, doc_date):
    return _extract_keyword_hits(
        text, vocab.PROCEDURES, "Procedure", doc_id, filename, dates, doc_date,
        confidence=0.75,
    )


def extract_entities_from_document(raw_doc):
    """
    Main entry point. Takes a RawDocument and returns:
      doc_type (str), doc_date (datetime|None), entities (list[Entity])
    """
    text = raw_doc.text
    doc_id = raw_doc.doc_id
    filename = raw_doc.filename

    doc_type = detect_doc_type(text)
    dates = find_dates(text)
    doc_date = doc_primary_date(dates)

    lab_results = extract_lab_results(text, doc_id, filename, dates, doc_date)
    covered_spans = [e.char_start for e in lab_results]
    lab_tests = extract_lab_tests_mentioned(text, doc_id, filename, dates, doc_date, covered_spans)
    medications = extract_medications(text, doc_id, filename, dates, doc_date)
    diagnoses = extract_diagnoses(text, doc_id, filename, dates, doc_date)
    symptoms = extract_symptoms(text, doc_id, filename, dates, doc_date)
    procedures = extract_procedures(text, doc_id, filename, dates, doc_date)
    followups = extract_followups(text, doc_id, filename, dates, doc_date)

    entities = (symptoms + lab_tests + lab_results + diagnoses +
                medications + procedures + followups)
    # entities without ANY date fall back to doc_date (may still be None)
    for e in entities:
        if e.date is None:
            e.date = doc_date

    return doc_type, doc_date, entities
