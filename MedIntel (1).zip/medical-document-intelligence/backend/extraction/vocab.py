"""
Curated medical vocabulary used by the rule-based extractor.
This is intentionally a plain, editable knowledge base (no external model
downloads / no internet needed) so the system is fully self-contained and
reliable to run offline. Extend these lists to widen coverage.
"""

DOCUMENT_TYPE_KEYWORDS = {
    "Discharge Summary": ["discharge summary", "discharged on", "hospital course"],
    "Prescription": ["prescription", "\nrx", " rx:", "medication order", "take as directed"],
    "Lab Report": ["lab report", "laboratory report", "test report", "pathology report",
                    "end of report"],
    "Imaging Report": ["imaging report", "ultrasound report", "radiology report",
                        "sonography", "impression:", "procedure performed"],
    "Clinical Note": ["clinical note", "progress note", "consultation note", "opd note",
                       "chief complaint", "on examination"],
}

SYMPTOMS = [
    "fever", "cough", "cold", "headache", "abdominal pain", "stomach pain",
    "chest pain", "shortness of breath", "breathlessness", "fatigue",
    "weakness", "dizziness", "vomiting", "nausea", "diarrhea", "constipation",
    "back pain", "joint pain", "swelling", "rash", "sore throat",
    "loss of appetite", "weight loss", "weight gain", "palpitation",
    "blurred vision", "numbness", "tingling", "bleeding", "burning sensation",
    "difficulty breathing", "loss of consciousness", "seizure", "anxiety",
    "insomnia", "night sweats", "chills", "body ache", "malaise",
]

LAB_TESTS = [
    "cbc", "complete blood count", "hemoglobin", "hb", "wbc", "white blood cell count",
    "platelet count", "esr", "crp", "blood sugar", "fasting blood sugar", "fbs",
    "post prandial blood sugar", "ppbs", "hba1c", "creatinine", "urea", "bun",
    "lft", "liver function test", "sgot", "sgpt", "bilirubin", "lipid profile",
    "cholesterol", "triglycerides", "ldl", "hdl", "tsh", "t3", "t4",
    "urine routine", "urinalysis", "blood culture", "vitamin d", "vitamin b12",
    "electrolytes", "sodium", "potassium", "calcium", "rbc count", "mcv", "mch",
]

# Regex-friendly canonical unit tokens used to find "Name: Value Unit" patterns
LAB_UNITS = ["g/dl", "mg/dl", "%", "mmol/l", "meq/l", "iu/l", "u/l", "cells/cumm",
             "/cumm", "ng/ml", "pg/ml", "miu/l", "mm/hr", "million/cumm", "k/ul"]

DIAGNOSES = [
    "anemia", "diabetes", "diabetes mellitus", "hypertension", "pneumonia",
    "urinary tract infection", "uti", "gastritis", "migraine", "asthma",
    "bronchitis", "tuberculosis", "hypothyroidism", "hyperthyroidism",
    "dengue", "malaria", "typhoid", "covid-19", "chronic kidney disease",
    "ckd", "coronary artery disease", "myocardial infarction", "stroke",
    "osteoarthritis", "rheumatoid arthritis", "jaundice", "hepatitis",
    "peptic ulcer disease", "irritable bowel syndrome", "depression", "anxiety disorder",
    "sinusitis", "pharyngitis", "cellulitis", "sepsis", "dehydration",
]

DIAGNOSIS_TRIGGERS = ["diagnosed with", "diagnosis:", "impression:", "assessment:",
                       "likely", "consistent with", "suggestive of", "provisional diagnosis"]

MEDICATION_FORMS = ["tab", "tablet", "cap", "capsule", "inj", "injection", "syrup",
                     "syp", "drops", "ointment", "cream", "patch"]

COMMON_DRUG_NAMES = [
    "iron", "ferrous sulfate", "paracetamol", "acetaminophen", "ibuprofen",
    "amoxicillin", "azithromycin", "ciprofloxacin", "metformin", "insulin",
    "amlodipine", "losartan", "atorvastatin", "omeprazole", "pantoprazole",
    "cetirizine", "levothyroxine", "salbutamol", "prednisolone", "diclofenac",
    "aspirin", "clopidogrel", "warfarin", "vitamin d3", "vitamin b12",
    "folic acid", "calcium carbonate", "ors", "domperidone", "ondansetron",
    "multivitamin", "cough syrup",
]

PROCEDURES = [
    "x-ray", "mri", "ct scan", "ultrasound", "sonography", "endoscopy",
    "colonoscopy", "biopsy", "ecg", "ekg", "echo", "echocardiogram",
    "angiography", "dialysis", "surgery", "operation", "catheterization",
    "physiotherapy",
]

FOLLOWUP_TRIGGERS = ["follow up", "follow-up", "review after", "come back after",
                      "revisit after", "next appointment", "reassess after"]

STOP_TRIGGERS = ["stopped", "discontinued", "withdrawn", "no longer taking"]
CHANGE_TRIGGERS = ["dosage changed", "dose increased", "dose decreased",
                    "changed to", "switched to", "revised dose"]
CONTINUE_TRIGGERS = ["continued", "continue", "same dose", "to continue"]
