"""
Deterministic date extraction. Rule-based (regex) rather than a fuzzy
NLP model, so results are reproducible and easy to trust/debug.
"""
import re
from datetime import datetime

MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9, "oct": 10,
    "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}

# Order matters: more specific patterns first.
DATE_PATTERNS = [
    # 2026-09-12
    (re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b"), "ymd"),
    # 12-09-2026 or 12/09/2026
    (re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b"), "dmy"),
    # 12 September 2026 / 12th September 2026
    (re.compile(
        r"\b(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,9})\s+(\d{4})\b"), "dMy"),
    # September 12, 2026 / Sep 12 2026
    (re.compile(
        r"\b([A-Za-z]{3,9})\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b"), "Mdy"),
]


def _safe_date(year, month, day):
    try:
        return datetime(year, month, day)
    except ValueError:
        return None


def find_dates(text):
    """
    Returns list of tuples: (datetime_obj, matched_text, start_index)
    sorted by position in the text.
    """
    found = []
    for pattern, kind in DATE_PATTERNS:
        for m in pattern.finditer(text):
            dt = None
            if kind == "ymd":
                y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
                dt = _safe_date(y, mo, d)
            elif kind == "dmy":
                d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
                dt = _safe_date(y, mo, d)
            elif kind == "dMy":
                d = int(m.group(1))
                mon_key = m.group(2).lower()[:4] if m.group(2).lower()[:4] in MONTHS else m.group(2).lower()
                mo = MONTHS.get(m.group(2).lower()[:3]) or MONTHS.get(m.group(2).lower())
                y = int(m.group(3))
                if mo:
                    dt = _safe_date(y, mo, d)
            elif kind == "Mdy":
                mo = MONTHS.get(m.group(1).lower()[:3]) or MONTHS.get(m.group(1).lower())
                d = int(m.group(2))
                y = int(m.group(3))
                if mo:
                    dt = _safe_date(y, mo, d)
            if dt:
                found.append((dt, m.group(0), m.start()))
    found.sort(key=lambda x: x[2])
    return found


def nearest_date_before(dates, index, fallback=None):
    """Given list of (dt, text, pos) sorted by pos, find the closest one
    at or before `index`. Falls back to the first date in the doc, then
    to `fallback`."""
    best = None
    for dt, _, pos in dates:
        if pos <= index:
            best = dt
        else:
            break
    if best is None and dates:
        best = dates[0][0]
    if best is None:
        best = fallback
    return best


def doc_primary_date(dates):
    """Earliest date mentioned is usually the document/event date for
    these short clinical documents."""
    if not dates:
        return None
    return min(d[0] for d in dates)
