"""
Flask API for the Medical Document Intelligence & Patient Timeline system.

Run:
    python -m backend.app
Then open http://127.0.0.1:5000 in a browser.
"""
import os
import sys
import tempfile

try:
    from flask import Flask, request, jsonify, send_from_directory
except ImportError:
    print("\nERROR: Flask is not installed in this Python environment.\n"
          "Fix: run this from the project's root folder:\n"
          "    pip install -r requirements.txt\n"
          "(Make sure you're running the same 'python'/'pip' you installed with,\n"
          " and that any virtual environment is activated.)\n")
    sys.exit(1)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend import storage
from backend.pipeline import process_documents
from backend.extraction.document_reader import load_documents_from_folder, load_document
from backend.graph.graph_builder import subgraph_for_date

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
SAMPLE_DIR = os.path.join(BASE_DIR, "sample_documents")

app = Flask(__name__, static_folder=None)


def _run_pipeline_and_store(raw_docs, patient_name="Demo Patient"):
    result, graph = process_documents(raw_docs, patient_name=patient_name)
    session_id = storage.new_session()
    storage.save(session_id, "result", result)
    storage.save(session_id, "graph", graph)
    return session_id, result


def _require_session(session_id):
    if not storage.exists(session_id):
        return jsonify({"error": "unknown session_id. Process documents first."}), 404
    return None


# ---------------------------------------------------------------- frontend --
@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ------------------------------------------------------------- processing --
@app.route("/api/demo", methods=["POST"])
def run_demo():
    """Loads the bundled sample documents (a realistic multi-document
    patient record) and runs the full pipeline."""
    raw_docs = load_documents_from_folder(SAMPLE_DIR)
    session_id, result = _run_pipeline_and_store(raw_docs, patient_name="Demo Patient")
    return jsonify({"session_id": session_id, **result})


@app.route("/api/upload", methods=["POST"])
def upload_documents():
    """Accepts multipart file uploads (.txt or .pdf), each representing
    one source document (lab report, prescription, discharge summary,
    imaging report, clinical note, ...)."""
    files = request.files.getlist("documents")
    if not files:
        return jsonify({"error": "No files uploaded under field 'documents'."}), 400

    patient_name = request.form.get("patient_name", "Patient")
    raw_docs = []
    with tempfile.TemporaryDirectory() as tmp:
        for f in files:
            path = os.path.join(tmp, f.filename)
            f.save(path)
            raw_docs.append(load_document(path, filename=f.filename))
        session_id, result = _run_pipeline_and_store(raw_docs, patient_name=patient_name)

    return jsonify({"session_id": session_id, **result})


# ------------------------------------------------------------------- reads --
@app.route("/api/result/<session_id>")
def get_result(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result"))


@app.route("/api/timeline/<session_id>")
def get_timeline(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["timeline"])


@app.route("/api/graph/<session_id>")
def get_graph(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["graph"])


@app.route("/api/graph/<session_id>/highlight/<date_str>")
def get_graph_highlight(session_id, date_str):
    err = _require_session(session_id)
    if err:
        return err
    graph = storage.get(session_id, "graph")
    return jsonify(subgraph_for_date(graph, date_str))


@app.route("/api/medications/<session_id>")
def get_medications(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["medication_journeys"])


@app.route("/api/labs/<session_id>")
def get_labs(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["lab_trends"])


@app.route("/api/conflicts/<session_id>")
def get_conflicts(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["conflicts"])


@app.route("/api/documents/<session_id>")
def get_documents(session_id):
    err = _require_session(session_id)
    if err:
        return err
    return jsonify(storage.get(session_id, "result")["documents"])


@app.route("/api/node/<session_id>/<node_id>")
def get_node(session_id, node_id):
    err = _require_session(session_id)
    if err:
        return err
    graph = storage.get(session_id, "graph")
    if node_id not in graph.nodes:
        return jsonify({"error": "node not found"}), 404
    data = dict(graph.nodes[node_id])
    data["node_id"] = node_id
    return jsonify(data)


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    import socket

    port = 5000
    # If 5000 is already taken (common on macOS due to AirPlay Receiver,
    # or a leftover process from a previous run), fall back automatically
    # instead of crashing with an unhelpful traceback.
    for candidate in (5000, 5050, 8000, 8080):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", candidate))
                port = candidate
                break
            except OSError:
                continue

    print("=" * 60)
    print(f"  Medical Document Intelligence server starting...")
    print(f"  Open this in your browser:  http://127.0.0.1:{port}")
    print("  Press CTRL+C to stop the server.")
    print("=" * 60)
    app.run(debug=False, host="0.0.0.0", port=port)
