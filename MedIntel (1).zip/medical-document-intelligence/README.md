# Medical Document Intelligence & Patient Timeline

A working, self-contained prototype that turns a pile of unrelated medical
documents (lab reports, prescriptions, discharge summaries, imaging reports,
clinical notes) into one connected, chronological view of a patient's
history — with every fact traceable back to its source document.

No internet access or external AI API is required to run it: extraction is
rule-based (regex + a curated medical vocabulary), so it is fast, fully
offline, deterministic, and easy to audit/extend.

## Features

| Module | What it does |
|---|---|
| **Information extraction** | Pulls symptoms, lab tests, lab results (value + unit), diagnoses, medications (name/dosage/frequency), procedures and follow-ups out of raw text, regardless of which of the 5 document types it came from. |
| **Document understanding** | Auto-detects document type (Clinical Note / Lab Report / Prescription / Discharge Summary / Imaging Report) and the document's date. |
| **Cross-Document Relationship Graph** | Builds a typed graph (`networkx`) connecting Patient → Symptom → LabTest → LabResult → Diagnosis → Medication → FollowUp, both within a single document and **across** documents (temporal linking, lab-trend chains, medication-journey chains). |
| **Chronological timeline** | Groups every extracted, dated event by day into a day-by-day patient timeline. |
| **Timeline ↔ Graph linking** | Clicking a date in the timeline highlights exactly the graph nodes/edges relevant to that day. |
| **Medication journey** | Tracks each drug across all documents: started / continued / dosage changed / stopped / mentioned again. |
| **Lab trend analysis** | Groups repeated lab tests (e.g. Hemoglobin) across documents into a series, sorted by date, with a factual (not clinical) increasing/decreasing/stable label. |
| **Conflict detection** | Flags when two documents disagree about a patient's current medication (different drug, or different dosage) within a time window, with no note explaining the change - for human review. |
| **Source traceability** | Every extracted fact and every graph node carries `source_filename` + the exact evidence snippet it was extracted from. |

## Quick start

```bash
cd medical-document-intelligence
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python3 -m backend.app
```

Then open **http://127.0.0.1:5000** in a browser and click
**"Load demo patient record"** to see the full pipeline run on the bundled
7-document sample case (abdominal pain → CBC → anemia diagnosis → iron
prescription → conflicting medication mention → improved follow-up labs).

Or just run:
```bash
./run.sh
```
which creates the venv, installs dependencies, and starts the server for you.

To try it on your own files, use the file picker in the toolbar (`.txt` or
`.pdf`) and click **"Process uploaded documents"**.

### Command-line smoke test (no server needed)
```bash
python3 tests/test_pipeline.py
```
Prints the full extracted timeline / graph / medication journeys / lab
trends / conflicts for the sample documents and asserts the pipeline is
producing sane output - useful for verifying the install and for quick
regression checks after editing the vocabulary or rules.

## Project layout

```
backend/
  extraction/
    vocab.py            curated medical keyword lists (symptoms, labs, drugs, diagnoses...)
    date_utils.py        deterministic regex-based date parsing
    document_reader.py   loads .txt / .pdf into RawDocument objects
    entity_extractor.py  the core rule-based NER: turns raw text -> typed, dated, sourced Entities
  graph/
    graph_builder.py     builds the Cross-Document Relationship Graph (networkx)
  timeline/
    timeline_builder.py  groups entities into a day-by-day timeline
  analysis/
    medication_journey.py  per-drug status history across documents
    lab_trends.py           per-test value series across documents
    conflict_detector.py    flags contradictory medication records
  pipeline.py            orchestrates the above end to end
  storage.py             tiny in-memory session store
  app.py                 Flask API + serves the frontend
frontend/
  index.html            single-page UI (timeline, graph, medications, labs, conflicts, documents)
sample_documents/        7 realistic sample documents forming one coherent patient case
tests/
  test_pipeline.py       CLI smoke test / regression check
```

## How extraction works (and how to extend it)

Rather than depending on a downloaded ML model (which would need network
access and GPU/CPU time, and would be a black box), this prototype uses:

1. **A curated vocabulary** (`backend/extraction/vocab.py`) of common
   symptoms, lab tests, diagnoses, drug forms, and procedures.
2. **Deterministic regexes** for dates (`date_utils.py`), lab result
   patterns (`Name: Value Unit`), medication patterns (`Tab DrugName
   200mg once daily`), and follow-up phrases.
3. Every match keeps its **character offset**, so the exact sentence it
   came from can always be shown as evidence.

This is intentionally simple and inspectable - reliable and fast for a
working demo, and every list/regex in `vocab.py` / `entity_extractor.py`
can be extended with more terms to widen coverage. For a production
system, this layer is the natural place to swap in / augment with a
medical NER model (e.g. a fine-tuned transformer or a clinical NLP
library) while keeping the same `Entity` interface, so the graph,
timeline and analysis modules downstream do not need to change.

## How the relationship graph is built

* **Node types**: `Patient`, `Symptom`, `LabTest`, `LabResult`, `Diagnosis`,
  `Medication`, `Procedure`, `FollowUp`.
* **Within a document**: entities are chained in clinical order
  (Symptom → LabTest → LabResult → Diagnosis → Medication → FollowUp).
* **Across documents**: entities of a "supports/leads-to" type pair
  occurring in different documents within a configurable time window
  (default 21 days) are linked too - e.g. a lab result in one document
  and a diagnosis appearing in a later document.
* **Lab trend chains**: repeated mentions of the same test are chained
  `followed_by` in date order.
* **Medication journey chains**: repeated mentions of the same drug are
  chained `started` → `continued` / `dosage_changed` / `stopped`.

Every node keeps `source_filename` + `evidence` so the graph is always
"AI extraction + relationship + evidence", never an unexplained black box.

## Known limitations (by design, for a working prototype)

* Extraction is rule-based, not a trained clinical NER model - vocabulary
  coverage is limited to the lists in `vocab.py`. This keeps the system
  fast, offline and explainable, at the cost of recall on terms not in
  the list.
* Cross-document linking uses a time-window heuristic, not deep semantic
  reasoning - it will sometimes link two clinically-unrelated events that
  happen to fall close together in time (and, symmetrically, sometimes
  miss a real relationship spanning a longer gap). This is a reasonable
  trade-off for a transparent, debuggable v1.
* Conflict detection is intentionally conservative and *flags for human
  review* - it does not (and should not) make a clinical judgement about
  which record is correct. In the bundled demo data, for example, it also
  flags "Iron" + "Folic Acid" (a legitimate co-prescription) alongside the
  genuine unexplained "Iron" → "Multivitamin" switch, to illustrate that
  every flag is a prompt to check, not a diagnosis.
* In-memory session storage - swap `backend/storage.py` for a real database
  for multi-user / persistent use.
