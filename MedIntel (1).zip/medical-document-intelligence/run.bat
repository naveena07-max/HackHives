@echo off
REM Convenience launcher for Windows: creates a venv (first run only),
REM installs dependencies, and starts the server.
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo ERROR: 'python' was not found on PATH.
    echo Install Python 3 from https://www.python.org/downloads/
    echo and make sure to check "Add python.exe to PATH" during install.
    echo.
    pause
    exit /b 1
)

if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat
echo Installing dependencies...
pip install -q -r requirements.txt
echo.
python -m backend.app
pause
