#!/usr/bin/env bash
# Convenience launcher: creates a venv (first run only), installs
# dependencies, and starts the Flask server.
set -e
cd "$(dirname "$0")"

# Prefer python3, fall back to python
PYBIN="python3"
if ! command -v python3 >/dev/null 2>&1; then
  if command -v python >/dev/null 2>&1; then
    PYBIN="python"
  else
    echo ""
    echo "ERROR: Python 3 was not found on your PATH."
    echo "Install it from https://www.python.org/downloads/ and try again."
    echo ""
    exit 1
  fi
fi

if [ ! -d ".venv" ]; then
  echo "Creating virtual environment..."
  "$PYBIN" -m venv .venv
fi

source .venv/bin/activate
echo "Installing dependencies..."
pip install -q -r requirements.txt
echo ""
python3 -m backend.app
